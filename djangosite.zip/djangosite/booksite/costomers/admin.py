# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from costomers.models import *
# Register your models here.

admin.site.register(Book)
