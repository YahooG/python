#!/bin/bash

# vim: vim editor software
# ibus-libpinyin: pinyin inputer.
# ibus-table-wubi: wubi inputer.


sudo apt-get install vim ibus-libpinyin ibus-table-wubi exuberant-ctags cscope  -y

