#!/usr/bin/python

print 1
print 1.2
print "hello"
print [1,2,3,4,5]
print (1,2,3,4,5)
print {1,2,3,4,5}
print {'a':1,'b':2}

print "======================================="
a = "h2llo"

print a

print "key:",a,"!!!",

print "test"

b = 1
c = 1.25678

print "a = %s,b = %d !!!"%(a,b)

print "c = %.*f"%(3,c)
