l = [1,2,3,4,5]

a = l.count(3)

print l.append(5)

print a
