#!/usr/bin/python
#coding=utf-8

'''
我只是想做个注释
...
'''
print """
        人生苦短 
        我用python
      """
