#!/usr/bin/python

s = "hello \nworld"

print s + "nihao"


#print dir(s)
