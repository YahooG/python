#!/usr/bin/env python

import math

print dir(math)
#print help(math.pow)

print math.pow(3,4)
