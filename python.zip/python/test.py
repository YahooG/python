#!/usr/bin/python

a,b = 1,2

if True:
    print "a < b"
    print "a < b"
    print "a < b"


print "end"
