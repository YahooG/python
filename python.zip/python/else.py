#!/usr/bin/python

from time import  sleep


while True:
    sleep(2)
    print "666"
else:
    print "while end"
