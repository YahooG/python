a = 4

def fun():
    b = 1
    print a

fun()
print b
