def fun():
    i = 1
    while i < 10:
        i += 1
        if i == 4:
            return
        print i

fun()
