#!/usr/bin/python

sum = i = 0

while i <= 100:
    sum += i
    i += 1

print "sum = %d"%sum
