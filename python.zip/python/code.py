#!/usr/bin/python 
#coding=utf-8

print "你好"
