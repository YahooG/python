#!/usr/bin/python

a,c = input("Please input>>")

print "a =",a
print "c =",c


b = raw_input()

print "b =",b
print type(b)
