#coding=utf-8
import sys

#with open('file1','r+') as f:
#    s = f.read(10)
#    s1 = f.readline(12)
#    s2 = f.readline(12)
#    s3 = f.readlines()

#print s
#print s1
#print s2
#print s3


s = sys.stdin.readline()
print s
