#coding=utf-8

f = open('file2','a+')

#f.write("君若为磐石，妾当为蒲苇，\n磐石无转移，蒲苇韧如丝")

f.writelines(['hello\n','world\n','1\n','2'])
