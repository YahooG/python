class Magic(object):
    '''This is Magic doc'''
    pass

print dir(Magic)
print "=============================="

print Magic.__module__
print Magic.__class__
print Magic.__doc__
